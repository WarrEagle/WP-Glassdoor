/**
 * WPGlassdoor Javascript
 *
 * @package  WPGlassdoor
 * @author  Predrag Bradaric
 * @since  1.0
 */

jQuery(document).ready(function() {


});