    <div id="icon-plugins" class="icon32"></div>
    <h2 id="wpgd-title">WP Glassdoor / <?php echo $page; ?></h2>
