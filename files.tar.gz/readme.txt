=== WP Glassdoor ===
Contributors: Predrag Bradaric
Donate link: http://bradaric.com
Tags: glassdoor, jobs, job, job feed
Requires at least: 3.3
Tested up to: 3.5.2
Stable tag: trunk

WP Glassdoor is a plugin that adds Glassdoor "Job Title Salary Widget" to WordPress widgets.

== Description ==

WP Glassdoor is a plugin that adds Glassdoor "Job Title Salary Widget" to WordPress widgets.

== Installation ==

1. Unzip the WP Glassdoor zip file, it will contain one folder called wpgd

2. Use an FTP client to upload the unzipped wpgd directory into your WordPress /wp-content/plugins/ folder

3. Logon to your WordPress administration area and go to the PLUGINS tab, scroll down to WP Glassdoor and click to activate the plugin

4. After activation a new WP Glassdoor tab will appear at the bottom of the sidebar in your blog's administration area. From here you can access the WP Glassdoor admin area.

== How to use it ==


== Screenshots ==

[Click here for screenshots.]

== Frequently Asked Questions ==


== Changelog ==

== Upgrade Notice ==
Please upgrade now to use the latest features.
